from __future__ import annotations

from typing import Callable, Optional

import customtkinter as ctk

from storage import Shortcut, ShortcutStorage, TriggerMode


# Pure Minimalist Dark Mode Palette
BG_CANVAS = "#0F0F0F"
BG_SURFACE = "#181818"
BG_INPUT = "#121212"
BG_HOVER = "#222222"
BORDER_SUBTLE = "#2A2A2A"
TEXT_PRIMARY = "#FFFFFF"
TEXT_MUTED = "#9A9A9A"
TEXT_DIM = "#666666"
ACCENT_PRIMARY = "#FFFFFF"
ACCENT_TEXT = "#0F0F0F"
DANGER_TEXT = "#EF4444"


class QuickTextDashboard(ctk.CTk):
    """Minimalist dark-mode CustomTkinter management dashboard for QuickText."""

    def __init__(
        self,
        storage: ShortcutStorage,
        on_settings_changed: Callable[[], None],
        on_minimize_to_tray: Callable[[], None],
    ) -> None:
        super().__init__()
        self._storage = storage
        self._on_settings_changed = on_settings_changed
        self._on_minimize_to_tray = on_minimize_to_tray
        self._editing_id: Optional[str] = None

        ctk.set_appearance_mode("dark")
        self.title("QuickText — Text Shortcuts")
        self.geometry("920x680")
        self.minsize(780, 560)
        self.configure(fg_color=BG_CANVAS)

        # Clicking X minimizes to Windows System Tray instead of closing
        self.protocol("WM_DELETE_WINDOW", self._handle_close_to_tray)

        self._build_layout()
        self.sync_from_storage()

    def _build_layout(self) -> None:
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(3, weight=1)

        # ── 1. Header Bar ──────────────────────────────────────────────────
        header = ctk.CTkFrame(
            self,
            fg_color=BG_SURFACE,
            border_width=1,
            border_color=BORDER_SUBTLE,
            corner_radius=10,
        )
        header.grid(row=0, column=0, padx=20, pady=(20, 12), sticky="ew")
        header.grid_columnconfigure(1, weight=1)

        title_wrap = ctk.CTkFrame(header, fg_color="transparent")
        title_wrap.grid(row=0, column=0, padx=16, pady=14, sticky="w")

        ctk.CTkLabel(
            title_wrap,
            text="QuickText",
            font=("Segoe UI", 18, "bold"),
            text_color=TEXT_PRIMARY,
        ).pack(side="left")

        self._status_label = ctk.CTkLabel(
            title_wrap,
            text="·  Listening",
            font=("Segoe UI", 12),
            text_color=TEXT_MUTED,
        )
        self._status_label.pack(side="left", padx=(8, 0))

        controls_wrap = ctk.CTkFrame(header, fg_color="transparent")
        controls_wrap.grid(row=0, column=2, padx=16, pady=12, sticky="e")

        # Global Case Sensitivity Checkbox
        self._global_case_var = ctk.BooleanVar(value=False)
        self._global_case_chk = ctk.CTkCheckBox(
            controls_wrap,
            text="Case Sensitive",
            variable=self._global_case_var,
            command=self._handle_global_case_toggle,
            font=("Segoe UI", 12),
            text_color=TEXT_MUTED,
            fg_color=ACCENT_PRIMARY,
            checkmark_color=ACCENT_TEXT,
            border_color=BORDER_SUBTLE,
            hover_color=BG_HOVER,
            border_width=1,
            checkbox_width=16,
            checkbox_height=16,
        )
        self._global_case_chk.pack(side="left", padx=(0, 16))

        # Mode Selector (Instant No Key vs Space/Enter vs Popup Suggestion)
        self._mode_seg = ctk.CTkSegmentedButton(
            controls_wrap,
            values=["Instant (No Key)", "Space / Enter", "Popup"],
            command=self._handle_mode_change,
            fg_color=BG_INPUT,
            selected_color=ACCENT_PRIMARY,
            selected_hover_color="#E5E5E5",
            unselected_color=BG_INPUT,
            unselected_hover_color=BG_HOVER,
            text_color=TEXT_PRIMARY,
            font=("Segoe UI", 12, "bold"),
            height=32,
            corner_radius=6,
        )
        self._mode_seg.pack(side="left", padx=(0, 16))

        # Active / Paused Switch
        self._enabled_var = ctk.BooleanVar(value=True)
        self._enabled_switch = ctk.CTkSwitch(
            controls_wrap,
            text="Active",
            variable=self._enabled_var,
            command=self._handle_enabled_toggle,
            font=("Segoe UI", 12, "bold"),
            text_color=TEXT_PRIMARY,
            fg_color="#333333",
            progress_color=ACCENT_PRIMARY,
            button_color="#CCCCCC",
            button_hover_color="#FFFFFF",
            width=42,
        )
        self._enabled_switch.pack(side="left")

        # ── 2. Add / Edit Shortcut Bar ─────────────────────────────────────
        editor = ctk.CTkFrame(
            self,
            fg_color=BG_SURFACE,
            border_width=1,
            border_color=BORDER_SUBTLE,
            corner_radius=10,
        )
        editor.grid(row=1, column=0, padx=20, pady=(0, 12), sticky="ew")
        editor.grid_columnconfigure(1, weight=1)

        # Trigger Column
        trigger_col = ctk.CTkFrame(editor, fg_color="transparent")
        trigger_col.grid(row=0, column=0, padx=(16, 12), pady=14, sticky="nw")

        ctk.CTkLabel(
            trigger_col,
            text="Trigger Shortcut",
            font=("Segoe UI", 12),
            text_color=TEXT_MUTED,
        ).pack(anchor="w", pady=(0, 6))

        self._trigger_entry = ctk.CTkEntry(
            trigger_col,
            placeholder_text="e.g. it",
            width=180,
            height=36,
            fg_color=BG_INPUT,
            border_color=BORDER_SUBTLE,
            border_width=1,
            text_color=TEXT_PRIMARY,
            placeholder_text_color=TEXT_DIM,
            font=("Consolas", 13),
            corner_radius=6,
        )
        self._trigger_entry.pack(anchor="w")

        self._shortcut_case_var = ctk.BooleanVar(value=False)
        self._shortcut_case_chk = ctk.CTkCheckBox(
            trigger_col,
            text="Match case",
            variable=self._shortcut_case_var,
            font=("Segoe UI", 11),
            text_color=TEXT_MUTED,
            fg_color=ACCENT_PRIMARY,
            checkmark_color=ACCENT_TEXT,
            border_color=BORDER_SUBTLE,
            hover_color=BG_HOVER,
            border_width=1,
            checkbox_width=15,
            checkbox_height=15,
        )
        self._shortcut_case_chk.pack(anchor="w", pady=(10, 0))

        # Expansion Column (Multi-line)
        expansion_col = ctk.CTkFrame(editor, fg_color="transparent")
        expansion_col.grid(row=0, column=1, padx=(0, 12), pady=14, sticky="nsew")

        ctk.CTkLabel(
            expansion_col,
            text="Expanded Text (multi-line supported)",
            font=("Segoe UI", 12),
            text_color=TEXT_MUTED,
        ).pack(anchor="w", pady=(0, 6))

        self._expansion_box = ctk.CTkTextbox(
            expansion_col,
            height=68,
            fg_color=BG_INPUT,
            border_color=BORDER_SUBTLE,
            border_width=1,
            text_color=TEXT_PRIMARY,
            font=("Segoe UI", 13),
            corner_radius=6,
            wrap="word",
        )
        self._expansion_box.pack(fill="x", expand=True)

        # Action Column
        action_col = ctk.CTkFrame(editor, fg_color="transparent")
        action_col.grid(row=0, column=2, padx=(0, 16), pady=14, sticky="se")

        self._save_btn = ctk.CTkButton(
            action_col,
            text="Add Shortcut",
            command=self._handle_save_shortcut,
            fg_color=ACCENT_PRIMARY,
            hover_color="#E5E5E5",
            text_color=ACCENT_TEXT,
            font=("Segoe UI", 12, "bold"),
            height=36,
            width=124,
            corner_radius=6,
        )
        self._save_btn.pack(fill="x")

        self._cancel_btn = ctk.CTkButton(
            action_col,
            text="Cancel",
            command=self._cancel_edit,
            fg_color="transparent",
            hover_color=BG_HOVER,
            border_width=1,
            border_color=BORDER_SUBTLE,
            text_color=TEXT_MUTED,
            font=("Segoe UI", 12),
            height=30,
            width=124,
            corner_radius=6,
        )

        # ── 3. Search & Filter Bar ─────────────────────────────────────────
        search_row = ctk.CTkFrame(self, fg_color="transparent")
        search_row.grid(row=2, column=0, padx=20, pady=(0, 10), sticky="ew")
        search_row.grid_columnconfigure(0, weight=1)

        self._search_var = ctk.StringVar()
        self._search_var.trace_add("write", lambda *_: self.render_shortcuts())

        self._search_entry = ctk.CTkEntry(
            search_row,
            textvariable=self._search_var,
            placeholder_text="Search shortcuts or expanded phrases...",
            height=36,
            fg_color=BG_SURFACE,
            border_color=BORDER_SUBTLE,
            border_width=1,
            text_color=TEXT_PRIMARY,
            placeholder_text_color=TEXT_DIM,
            font=("Segoe UI", 13),
            corner_radius=8,
        )
        self._search_entry.grid(row=0, column=0, sticky="ew")

        self._count_label = ctk.CTkLabel(
            search_row,
            text="0 shortcuts",
            font=("Segoe UI", 12),
            text_color=TEXT_DIM,
        )
        self._count_label.grid(row=0, column=1, padx=(14, 0))

        # ── 4. Shortcuts List ──────────────────────────────────────────────
        self._list_frame = ctk.CTkScrollableFrame(
            self,
            fg_color=BG_SURFACE,
            border_width=1,
            border_color=BORDER_SUBTLE,
            corner_radius=10,
            scrollbar_button_color="#2A2A2A",
            scrollbar_button_hover_color="#3D3D3D",
        )
        self._list_frame.grid(row=3, column=0, padx=20, pady=(0, 20), sticky="nsew")
        self._list_frame.grid_columnconfigure(0, weight=1)

    def sync_from_storage(self) -> None:
        settings = self._storage.get_settings()
        self._enabled_var.set(settings.enabled)
        self._enabled_switch.configure(text="Active" if settings.enabled else "Paused")
        self._status_label.configure(text="·  Listening" if settings.enabled else "·  Paused")
        self._global_case_var.set(settings.global_case_sensitive)
        mode_label_map = {
            "immediate": "Instant (No Key)",
            "instant": "Space / Enter",
            "popup": "Popup",
        }
        self._mode_seg.set(mode_label_map.get(settings.mode, "Instant (No Key)"))
        self._update_segmented_text_color()
        self.render_shortcuts()

    def _update_segmented_text_color(self) -> None:
        # CustomTkinter draws selected segment text with text_color; keep contrast crisp
        for value, btn in self._mode_seg._buttons_dict.items():
            if value == self._mode_seg.get():
                btn.configure(text_color=ACCENT_TEXT)
            else:
                btn.configure(text_color=TEXT_MUTED)

    def render_shortcuts(self) -> None:
        for child in self._list_frame.winfo_children():
            child.destroy()

        query = self._search_var.get().strip().lower()
        shortcuts = self._storage.get_shortcuts()
        filtered = [
            sc
            for sc in shortcuts
            if not query
            or query in sc.trigger.lower()
            or query in sc.expansion.lower()
        ]

        self._count_label.configure(text=f"{len(filtered)} shortcuts")

        if not filtered:
            empty_msg = (
                "No shortcuts match your search."
                if query
                else "No shortcuts yet. Add a trigger above to begin."
            )
            ctk.CTkLabel(
                self._list_frame,
                text=empty_msg,
                font=("Segoe UI", 13),
                text_color=TEXT_DIM,
            ).grid(row=0, column=0, pady=48)
            return

        for idx, sc in enumerate(filtered):
            row = ctk.CTkFrame(
                self._list_frame,
                fg_color="transparent",
                corner_radius=0,
            )
            row.grid(row=idx * 2, column=0, sticky="ew", padx=8, pady=4)
            row.grid_columnconfigure(1, weight=1)

            # Trigger badge (flat monospace label)
            ctk.CTkLabel(
                row,
                text=sc.trigger,
                width=120,
                anchor="w",
                font=("Consolas", 13, "bold"),
                text_color=TEXT_PRIMARY,
            ).grid(row=0, column=0, padx=(8, 12), pady=8, sticky="nw")

            # Expansion preview + quiet metadata
            preview_wrap = ctk.CTkFrame(row, fg_color="transparent")
            preview_wrap.grid(row=0, column=1, padx=(0, 12), pady=8, sticky="ew")

            preview_text = sc.expansion.replace("\r\n", "\n")
            if len(preview_text) > 140:
                preview_text = preview_text[:137] + "..."

            ctk.CTkLabel(
                preview_wrap,
                text=preview_text,
                anchor="w",
                justify="left",
                font=("Segoe UI", 13),
                text_color="#E0E0E0",
            ).pack(anchor="w", fill="x")

            meta_parts = []
            if sc.case_sensitive:
                meta_parts.append("Case-sensitive")
            else:
                meta_parts.append("Case-insensitive")
            if "\n" in sc.expansion:
                meta_parts.append("Multi-line")

            ctk.CTkLabel(
                preview_wrap,
                text=" · ".join(meta_parts),
                anchor="w",
                font=("Segoe UI", 11),
                text_color=TEXT_DIM,
            ).pack(anchor="w", pady=(2, 0))

            # Edit / Delete buttons
            btns = ctk.CTkFrame(row, fg_color="transparent")
            btns.grid(row=0, column=2, padx=(0, 6), pady=8, sticky="ne")

            ctk.CTkButton(
                btns,
                text="Edit",
                width=58,
                height=28,
                fg_color="transparent",
                hover_color=BG_HOVER,
                border_width=1,
                border_color=BORDER_SUBTLE,
                text_color=TEXT_MUTED,
                font=("Segoe UI", 11),
                corner_radius=6,
                command=lambda item=sc: self._start_edit(item),
            ).pack(side="left", padx=(0, 6))

            ctk.CTkButton(
                btns,
                text="Delete",
                width=64,
                height=28,
                fg_color="transparent",
                hover_color="#2A1616",
                border_width=1,
                border_color=BORDER_SUBTLE,
                text_color=DANGER_TEXT,
                font=("Segoe UI", 11),
                corner_radius=6,
                command=lambda sid=sc.id: self._handle_delete(sid),
            ).pack(side="left")

            if idx < len(filtered) - 1:
                sep = ctk.CTkFrame(self._list_frame, height=1, fg_color=BORDER_SUBTLE)
                sep.grid(row=idx * 2 + 1, column=0, sticky="ew", padx=12)

    def _handle_enabled_toggle(self) -> None:
        enabled = bool(self._enabled_var.get())
        self._storage.update_settings(enabled=enabled)
        self._enabled_switch.configure(text="Active" if enabled else "Paused")
        self._status_label.configure(text="·  Listening" if enabled else "·  Paused")
        self._on_settings_changed()

    def _handle_global_case_toggle(self) -> None:
        self._storage.update_settings(global_case_sensitive=bool(self._global_case_var.get()))
        self._on_settings_changed()

    def _handle_mode_change(self, selected: str) -> None:
        label_to_mode: dict[str, TriggerMode] = {
            "Instant (No Key)": "immediate",
            "Space / Enter": "instant",
            "Popup": "popup",
        }
        mode: TriggerMode = label_to_mode.get(selected, "immediate")
        self._storage.update_settings(mode=mode)
        self._update_segmented_text_color()
        self._on_settings_changed()

    def _handle_save_shortcut(self) -> None:
        trigger = self._trigger_entry.get().strip()
        expansion = self._expansion_box.get("1.0", "end-1c")
        case_sensitive = bool(self._shortcut_case_var.get())

        if not trigger or not expansion:
            return

        if self._editing_id is not None:
            self._storage.update_shortcut(self._editing_id, trigger, expansion, case_sensitive)
        else:
            self._storage.add_shortcut(trigger, expansion, case_sensitive)

        self._cancel_edit()
        self.render_shortcuts()

    def _start_edit(self, sc: Shortcut) -> None:
        self._editing_id = sc.id
        self._trigger_entry.delete(0, "end")
        self._trigger_entry.insert(0, sc.trigger)
        self._expansion_box.delete("1.0", "end")
        self._expansion_box.insert("1.0", sc.expansion)
        self._shortcut_case_var.set(sc.case_sensitive)
        self._save_btn.configure(text="Save Changes")
        self._cancel_btn.pack(fill="x", pady=(8, 0))
        self._trigger_entry.focus_set()

    def _cancel_edit(self) -> None:
        self._editing_id = None
        self._trigger_entry.delete(0, "end")
        self._expansion_box.delete("1.0", "end")
        self._shortcut_case_var.set(False)
        self._save_btn.configure(text="Add Shortcut")
        self._cancel_btn.pack_forget()

    def _handle_delete(self, shortcut_id: str) -> None:
        if self._editing_id == shortcut_id:
            self._cancel_edit()
        self._storage.delete_shortcut(shortcut_id)
        self.render_shortcuts()

    def _handle_close_to_tray(self) -> None:
        self.withdraw()
        self._on_minimize_to_tray()

    def show_window(self) -> None:
        self.deiconify()
        self.lift()
        self.focus_force()
