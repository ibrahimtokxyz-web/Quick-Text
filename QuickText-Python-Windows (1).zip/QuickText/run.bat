@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    echo [QuickText] Creating virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo [Error] Python 3.10+ not found. Please install Python from python.org and check "Add Python to PATH".
        pause
        exit /b 1
    )
)

echo [QuickText] Installing/checking dependencies...
".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 (
    echo [Error] Failed to install dependencies.
    pause
    exit /b 1
)

echo [QuickText] Starting QuickText...
start "" ".venv\Scripts\pythonw.exe" main.py
exit /b 0
