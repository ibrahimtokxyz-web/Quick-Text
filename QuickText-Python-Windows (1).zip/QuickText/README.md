# QuickText — Windows Desktop Text Expander

Lightweight, minimalist Dark Mode Windows desktop text expander written in Python 3.10+.

## Quickest Way to Run (Windows)

1. Extract the ZIP archive and open the `QuickText` folder.
2. Double-click **`run.bat`** — it automatically creates `.venv`, installs dependencies, and launches QuickText cleanly in the background.
3. To build a standalone `.exe`, double-click **`build_exe.bat`** (`dist\QuickText.exe`).

---

## Manual Terminal Setup (PowerShell)

Make sure you are inside the `QuickText` folder (where `main.py` and `requirements.txt` are located). Run each command one at a time:

1. Create virtual environment:
```powershell
python -m venv .venv
```

2. Install dependencies:
```powershell
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
```

3. Run the application:
```powershell
.\.venv\Scripts\python.exe main.py
```

4. Optional — Compile standalone `.exe` (`--noconsole`):
```powershell
.\.venv\Scripts\pyinstaller.exe --noconsole --onefile --name QuickText --collect-all customtkinter --hidden-import pynput.keyboard._win32 --hidden-import pynput.mouse._win32 main.py
```
