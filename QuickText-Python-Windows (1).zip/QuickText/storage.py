from __future__ import annotations

import json
import os
import sys
import tempfile
import threading
import uuid
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import List, Literal, Optional


TriggerMode = Literal["immediate", "instant", "popup"]


def get_app_data_dir() -> Path:
    """Resolve persistent storage directory next to executable (PyInstaller) or script."""
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


@dataclass
class Shortcut:
    id: str
    trigger: str
    expansion: str
    case_sensitive: bool = False


@dataclass
class AppSettings:
    enabled: bool = True
    mode: TriggerMode = "immediate"
    global_case_sensitive: bool = False


DEFAULT_SHORTCUTS = [
    Shortcut(
        id="sc-1",
        trigger="it",
        expansion="İbrahim Tok",
        case_sensitive=False,
    ),
    Shortcut(
        id="sc-2",
        trigger="gün",
        expansion="Günaydın, iyi çalışmalar dilerim.",
        case_sensitive=False,
    ),
    Shortcut(
        id="sc-3",
        trigger="imza",
        expansion="Saygılarımla,\nİbrahim Tok\nSenior Software Engineer",
        case_sensitive=False,
    ),
    Shortcut(
        id="sc-4",
        trigger="mail",
        expansion="ibrahim.tok@example.com",
        case_sensitive=False,
    ),
    Shortcut(
        id="sc-5",
        trigger="tşk",
        expansion="İlginiz ve desteğiniz için çok teşekkür ederim.",
        case_sensitive=False,
    ),
]


class ShortcutStorage:
    """Thread-safe JSON storage for QuickText shortcuts and application settings."""

    def __init__(self, file_path: Optional[Path] = None) -> None:
        self.file_path: Path = file_path or (get_app_data_dir() / "shortcuts.json")
        self._lock = threading.RLock()
        self.settings: AppSettings = AppSettings()
        self.shortcuts: List[Shortcut] = []
        self.load()

    def load(self) -> None:
        with self._lock:
            if not self.file_path.exists():
                self.settings = AppSettings()
                self.shortcuts = list(DEFAULT_SHORTCUTS)
                self.save()
                return

            try:
                raw_text = self.file_path.read_text(encoding="utf-8")
                data = json.loads(raw_text)
            except (OSError, json.JSONDecodeError):
                self.settings = AppSettings()
                self.shortcuts = list(DEFAULT_SHORTCUTS)
                self.save()
                return

            raw_settings = data.get("settings", {})
            mode_val = raw_settings.get("mode", "immediate")
            if mode_val not in ("immediate", "instant", "popup"):
                mode_val = "immediate"

            self.settings = AppSettings(
                enabled=bool(raw_settings.get("enabled", True)),
                mode=mode_val,
                global_case_sensitive=bool(raw_settings.get("global_case_sensitive", False)),
            )

            loaded_shortcuts: List[Shortcut] = []
            for item in data.get("shortcuts", []):
                trigger = str(item.get("trigger", "")).strip()
                expansion = str(item.get("expansion", ""))
                if not trigger or not expansion:
                    continue
                loaded_shortcuts.append(
                    Shortcut(
                        id=str(item.get("id") or f"sc-{uuid.uuid4().hex[:8]}"),
                        trigger=trigger,
                        expansion=expansion,
                        case_sensitive=bool(item.get("case_sensitive", False)),
                    )
                )
            self.shortcuts = loaded_shortcuts

    def save(self) -> None:
        with self._lock:
            payload = {
                "settings": asdict(self.settings),
                "shortcuts": [asdict(sc) for sc in self.shortcuts],
            }
            self.file_path.parent.mkdir(parents=True, exist_ok=True)
            fd, tmp_path = tempfile.mkstemp(
                dir=str(self.file_path.parent),
                prefix=".shortcuts_",
                suffix=".tmp",
            )
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as tmp_file:
                    json.dump(payload, tmp_file, ensure_ascii=False, indent=2)
                os.replace(tmp_path, self.file_path)
            except Exception:
                if os.path.exists(tmp_path):
                    os.remove(tmp_path)
                raise

    def get_shortcuts(self) -> List[Shortcut]:
        with self._lock:
            return list(self.shortcuts)

    def get_settings(self) -> AppSettings:
        with self._lock:
            return AppSettings(**asdict(self.settings))

    def update_settings(
        self,
        *,
        enabled: Optional[bool] = None,
        mode: Optional[TriggerMode] = None,
        global_case_sensitive: Optional[bool] = None,
    ) -> AppSettings:
        with self._lock:
            if enabled is not None:
                self.settings.enabled = enabled
            if mode is not None and mode in ("immediate", "instant", "popup"):
                self.settings.mode = mode
            if global_case_sensitive is not None:
                self.settings.global_case_sensitive = global_case_sensitive
            self.save()
            return self.get_settings()

    def add_shortcut(
        self,
        trigger: str,
        expansion: str,
        case_sensitive: bool = False,
    ) -> Shortcut:
        clean_trigger = trigger.strip()
        if not clean_trigger:
            raise ValueError("Trigger shortcut cannot be empty.")
        if not expansion:
            raise ValueError("Expanded text cannot be empty.")

        with self._lock:
            new_item = Shortcut(
                id=f"sc-{uuid.uuid4().hex[:8]}",
                trigger=clean_trigger,
                expansion=expansion,
                case_sensitive=case_sensitive,
            )
            self.shortcuts.insert(0, new_item)
            self.save()
            return new_item

    def update_shortcut(
        self,
        shortcut_id: str,
        trigger: str,
        expansion: str,
        case_sensitive: bool,
    ) -> Optional[Shortcut]:
        clean_trigger = trigger.strip()
        if not clean_trigger or not expansion:
            raise ValueError("Trigger and expanded text cannot be empty.")

        with self._lock:
            for item in self.shortcuts:
                if item.id == shortcut_id:
                    item.trigger = clean_trigger
                    item.expansion = expansion
                    item.case_sensitive = case_sensitive
                    self.save()
                    return item
        return None

    def delete_shortcut(self, shortcut_id: str) -> bool:
        with self._lock:
            before = len(self.shortcuts)
            self.shortcuts = [s for s in self.shortcuts if s.id != shortcut_id]
            if len(self.shortcuts) != before:
                self.save()
                return True
        return False
