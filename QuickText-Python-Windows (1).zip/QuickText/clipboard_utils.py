from __future__ import annotations

import sys
import threading
import time
from typing import Optional

import pyperclip
from pynput.keyboard import Controller, Key, KeyCode


class ClipboardPaster:
    """
    Replaces a typed trigger with expanded Unicode text using Ctrl+V clipboard paste
    while preserving and restoring the user's prior clipboard text.
    """

    def __init__(self, simulating_flag: threading.Event) -> None:
        self._controller = Controller()
        self._simulating = simulating_flag
        self._paste_lock = threading.Lock()

    def replace_trigger_with_text(
        self,
        backspace_count: int,
        expansion_text: str,
        restore_delay_sec: float = 0.06,
        initial_delay_sec: float = 0.025,
    ) -> None:
        """
        Thread-safe expansion pipeline:
        1. Wait briefly so the final physical keystroke lands in the target app.
        2. Set simulation guard flag so global hook ignores our synthetic keystrokes.
        3. Save current clipboard text.
        4. Backspace the typed trigger (plus delimiter in Space/Enter mode).
        5. Copy expansion_text (UTF-8/UTF-16 safe for Turkish chars & multi-line) and paste via Ctrl+V.
        6. Wait ~50-60ms for target app to consume paste, then restore previous clipboard content.
        """
        if initial_delay_sec > 0:
            time.sleep(initial_delay_sec)

        with self._paste_lock:
            previous_clipboard: Optional[str] = None
            try:
                previous_clipboard = pyperclip.paste()
            except Exception:
                previous_clipboard = None

            self._simulating.set()
            try:
                # Release any modifier keys that might still be physically held briefly
                for mod in (Key.shift, Key.shift_r, Key.alt, Key.alt_l, Key.alt_r, Key.ctrl_l, Key.ctrl_r):
                    try:
                        self._controller.release(mod)
                    except Exception:
                        pass

                # Backspace the trigger characters
                for _ in range(max(0, backspace_count)):
                    self._controller.press(Key.backspace)
                    self._controller.release(Key.backspace)
                    time.sleep(0.002)

                # Copy target expansion text to Windows clipboard
                normalized_text = expansion_text.replace("\r\n", "\n")
                pyperclip.copy(normalized_text)
                time.sleep(0.015)

                # Simulate Ctrl+V paste (VK 0x56 works reliably across all keyboard layouts)
                v_key = KeyCode.from_vk(0x56) if sys.platform == "win32" else "v"
                with self._controller.pressed(Key.ctrl_l):
                    self._controller.press(v_key)
                    self._controller.release(v_key)

                # Allow target application time to read the pasted clipboard before restoring
                time.sleep(max(0.05, restore_delay_sec))
            finally:
                # Restore original clipboard content
                if previous_clipboard is not None:
                    try:
                        pyperclip.copy(previous_clipboard)
                    except Exception:
                        pass
                time.sleep(0.015)
                self._simulating.clear()
