@echo off
setlocal
cd /d "%~dp0"

if not exist ".venv\Scripts\python.exe" (
    python -m venv .venv
)

".venv\Scripts\python.exe" -m pip install --upgrade pip
".venv\Scripts\python.exe" -m pip install -r requirements.txt

echo [QuickText] Building standalone QuickText.exe...
".venv\Scripts\pyinstaller.exe" --noconsole --onefile --name QuickText --collect-all customtkinter --hidden-import pynput.keyboard._win32 --hidden-import pynput.mouse._win32 main.py

if errorlevel 1 (
    echo [Error] PyInstaller build failed.
    pause
    exit /b 1
)

echo.
echo [Done] Executable created at: "%~dp0dist\QuickText.exe"
pause
