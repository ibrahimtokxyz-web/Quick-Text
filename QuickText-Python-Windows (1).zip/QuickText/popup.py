from __future__ import annotations

import ctypes
from ctypes import wintypes
import sys
from typing import Callable, Optional, Tuple

import customtkinter as ctk


# Win32 Caret & Window constants
GWL_EXSTYLE = -20
WS_EX_NOACTIVATE = 0x08000000
WS_EX_TOPMOST = 0x00000008


class RECT(ctypes.Structure):
    _fields_ = [
        ("left", wintypes.LONG),
        ("top", wintypes.LONG),
        ("right", wintypes.LONG),
        ("bottom", wintypes.LONG),
    ]


class POINT(ctypes.Structure):
    _fields_ = [
        ("x", wintypes.LONG),
        ("y", wintypes.LONG),
    ]


class GUITHREADINFO(ctypes.Structure):
    _fields_ = [
        ("cbSize", wintypes.DWORD),
        ("flags", wintypes.DWORD),
        ("hwndActive", wintypes.HWND),
        ("hwndFocus", wintypes.HWND),
        ("hwndCapture", wintypes.HWND),
        ("hwndMenuOwner", wintypes.HWND),
        ("hwndMoveSize", wintypes.HWND),
        ("hwndCaret", wintypes.HWND),
        ("rcCaret", RECT),
    ]


def get_caret_screen_position() -> Optional[Tuple[int, int, int]]:
    """
    Query the active Windows GUI thread for the caret bounding box in screen coordinates.
    Returns (x, y_bottom, foreground_hwnd) if caret is exposed, else None.
    """
    if sys.platform != "win32":
        return None

    try:
        user32 = ctypes.windll.user32
        fg_hwnd = user32.GetForegroundWindow()
        thread_id = user32.GetWindowThreadProcessId(fg_hwnd, None) if fg_hwnd else 0

        info = GUITHREADINFO()
        info.cbSize = ctypes.sizeof(GUITHREADINFO)
        if user32.GetGUIThreadInfo(thread_id, ctypes.byref(info)):
            if info.hwndCaret and (info.rcCaret.right != 0 or info.rcCaret.bottom != 0):
                pt = POINT(info.rcCaret.left, info.rcCaret.bottom)
                if user32.ClientToScreen(info.hwndCaret, ctypes.byref(pt)):
                    return (int(pt.x), int(pt.y), int(fg_hwnd))
    except Exception:
        pass
    return None


def get_foreground_hwnd() -> int:
    if sys.platform != "win32":
        return 0
    try:
        return int(ctypes.windll.user32.GetForegroundWindow())
    except Exception:
        return 0


def restore_foreground_hwnd(hwnd: int) -> None:
    if sys.platform != "win32" or not hwnd:
        return
    try:
        ctypes.windll.user32.SetForegroundWindow(hwnd)
    except Exception:
        pass


class FloatingSuggestionPopup:
    """
    Sleek, borderless, non-intrusive dark-mode floating pill (SwiftKey style)
    displayed near the active typing caret or bottom-right screen corner.
    """

    def __init__(
        self,
        master: ctk.CTk,
        on_accept: Callable[[], None],
    ) -> None:
        self._master = master
        self._on_accept = on_accept
        self._visible = False
        self._target_hwnd: int = 0

        self._window = ctk.CTkToplevel(master)
        self._window.withdraw()
        self._window.overrideredirect(True)
        self._window.attributes("-topmost", True)
        self._window.configure(fg_color="#0F0F0F")

        # Container frame with 1px subtle border (#2A2A2A) and #181818 fill
        self._container = ctk.CTkFrame(
            self._window,
            fg_color="#181818",
            border_width=1,
            border_color="#2A2A2A",
            corner_radius=8,
        )
        self._container.pack(fill="both", expand=True)

        self._inner = ctk.CTkFrame(self._container, fg_color="transparent")
        self._inner.pack(padx=12, pady=8, fill="both", expand=True)

        self._trigger_label = ctk.CTkLabel(
            self._inner,
            text="",
            font=("Consolas", 11, "bold"),
            text_color="#9A9A9A",
            anchor="w",
        )
        self._trigger_label.pack(side="left", padx=(0, 8))

        self._divider = ctk.CTkFrame(
            self._inner,
            width=1,
            height=16,
            fg_color="#2A2A2A",
        )
        self._divider.pack(side="left", padx=(0, 8))

        self._expansion_label = ctk.CTkLabel(
            self._inner,
            text="",
            font=("Segoe UI", 13, "bold"),
            text_color="#FFFFFF",
            anchor="w",
        )
        self._expansion_label.pack(side="left", padx=(0, 12))

        self._hint_label = ctk.CTkLabel(
            self._inner,
            text="Tab / Enter",
            font=("Segoe UI", 11),
            text_color="#737373",
            anchor="e",
        )
        self._hint_label.pack(side="right")

        # Make entire popup clickable to accept expansion
        for widget in (
            self._window,
            self._container,
            self._inner,
            self._trigger_label,
            self._expansion_label,
            self._hint_label,
        ):
            widget.bind("<Button-1>", self._handle_click)

        self._apply_no_activate_style()

    def _apply_no_activate_style(self) -> None:
        if sys.platform != "win32":
            return
        try:
            self._window.update_idletasks()
            hwnd = ctypes.windll.user32.GetParent(self._window.winfo_id())
            if hwnd:
                style = ctypes.windll.user32.GetWindowLongW(hwnd, GWL_EXSTYLE)
                ctypes.windll.user32.SetWindowLongW(
                    hwnd,
                    GWL_EXSTYLE,
                    style | WS_EX_NOACTIVATE | WS_EX_TOPMOST,
                )
        except Exception:
            pass

    def _handle_click(self, _event=None) -> None:
        if self._target_hwnd:
            restore_foreground_hwnd(self._target_hwnd)
        self._on_accept()

    @property
    def is_visible(self) -> bool:
        return self._visible

    def show(self, trigger: str, expansion: str) -> None:
        preview = expansion.replace("\r\n", " ").replace("\n", " ↵ ")
        if len(preview) > 48:
            preview = preview[:45] + "..."

        self._trigger_label.configure(text=trigger)
        self._expansion_label.configure(text=preview)
        self._window.update_idletasks()

        req_w = max(200, self._window.winfo_reqwidth())
        req_h = max(36, self._window.winfo_reqheight())
        screen_w = self._window.winfo_screenwidth()
        screen_h = self._window.winfo_screenheight()

        caret_info = get_caret_screen_position()
        if caret_info is not None:
            cx, cy, fg_hwnd = caret_info
            self._target_hwnd = fg_hwnd
            pos_x = min(max(12, cx), screen_w - req_w - 12)
            pos_y = cy + 8
            if pos_y + req_h > screen_h - 48:
                pos_y = max(12, cy - req_h - 26)
        else:
            self._target_hwnd = get_foreground_hwnd()
            # Graceful bottom-right fallback when app (e.g. Electron/Chrome) doesn't expose Win32 caret
            pos_x = screen_w - req_w - 24
            pos_y = screen_h - req_h - 64

        self._window.geometry(f"{req_w}x{req_h}+{pos_x}+{pos_y}")
        self._window.deiconify()
        self._window.attributes("-topmost", True)
        self._apply_no_activate_style()
        self._visible = True

    def hide(self) -> None:
        if self._visible:
            self._window.withdraw()
            self._visible = False
