from __future__ import annotations

import ctypes
import queue
import sys
from typing import Any, Tuple

from gui import QuickTextDashboard
from keyboard_listener import GlobalInputEngine
from popup import FloatingSuggestionPopup
from storage import Shortcut, ShortcutStorage
from tray import SystemTrayController


def enable_windows_dpi_awareness() -> None:
    if sys.platform != "win32":
        return
    try:
        ctypes.windll.shcore.SetProcessDpiAwareness(1)
    except Exception:
        try:
            ctypes.windll.user32.SetProcessDPIAware()
        except Exception:
            pass


class QuickTextApplication:
    """
    Coordinates the CustomTkinter UI thread, GlobalInputEngine hook threads,
    FloatingSuggestionPopup, and Windows SystemTrayController via a thread-safe queue.
    """

    def __init__(self) -> None:
        enable_windows_dpi_awareness()
        self._ui_queue: queue.Queue[Tuple[str, Any]] = queue.Queue()
        self._storage = ShortcutStorage()

        self._dashboard = QuickTextDashboard(
            storage=self._storage,
            on_settings_changed=self._on_settings_changed,
            on_minimize_to_tray=lambda: None,
        )

        self._engine = GlobalInputEngine(
            storage=self._storage,
            on_show_popup=lambda sc: self._ui_queue.put(("show_popup", sc)),
            on_hide_popup=lambda: self._ui_queue.put(("hide_popup", None)),
        )

        self._popup = FloatingSuggestionPopup(
            master=self._dashboard,
            on_accept=self._engine.accept_popup_from_ui,
        )

        self._tray = SystemTrayController(
            on_open_dashboard=lambda: self._ui_queue.put(("open_dashboard", None)),
            on_toggle_listening=lambda: self._ui_queue.put(("toggle_listening", None)),
            on_exit=lambda: self._ui_queue.put(("exit_app", None)),
            is_listening_fn=lambda: self._storage.get_settings().enabled,
        )

    def _on_settings_changed(self) -> None:
        self._engine.reset_buffer()
        self._tray.refresh_state()

    def _poll_ui_queue(self) -> None:
        try:
            while True:
                event, payload = self._ui_queue.get_nowait()
                if event == "show_popup" and isinstance(payload, Shortcut):
                    self._popup.show(payload.trigger, payload.expansion)
                elif event == "hide_popup":
                    self._popup.hide()
                elif event == "open_dashboard":
                    self._dashboard.sync_from_storage()
                    self._dashboard.show_window()
                elif event == "toggle_listening":
                    current = self._storage.get_settings().enabled
                    self._storage.update_settings(enabled=not current)
                    self._dashboard.sync_from_storage()
                    self._on_settings_changed()
                elif event == "exit_app":
                    self.shutdown()
                    return
        except queue.Empty:
            pass

        self._dashboard.after(20, self._poll_ui_queue)

    def run(self) -> None:
        self._tray.start()
        self._engine.start()
        self._dashboard.after(20, self._poll_ui_queue)
        self._dashboard.mainloop()

    def shutdown(self) -> None:
        self._popup.hide()
        self._engine.stop()
        self._tray.stop()
        self._dashboard.quit()
        self._dashboard.destroy()


if __name__ == "__main__":
    app = QuickTextApplication()
    app.run()
