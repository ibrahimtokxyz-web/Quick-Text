from __future__ import annotations

import sys
import threading
from typing import Callable, Optional

from pynput import keyboard, mouse

from clipboard_utils import ClipboardPaster
from storage import Shortcut, ShortcutStorage


WM_KEYDOWN = 0x0100
WM_SYSKEYDOWN = 0x0104
VK_TAB = 0x09
VK_RETURN = 0x0D
VK_ESCAPE = 0x1B
LLKHF_INJECTED = 0x10

MAX_BUFFER_LENGTH = 64


class GlobalInputEngine:
    """
    Global background keyboard & mouse hook engine supporting:
    - Mode A: Floating Popup Suggestion (SwiftKey-style Tab/Enter/Click accept)
    - Mode B: Instant Auto-Expand on Space/Enter delimiter
    - Rolling buffer with Backspace, delimiter, navigation, and mouse-click resets
    - Infinite recursion prevention via simulation lock + LLKHF_INJECTED check
    """

    def __init__(
        self,
        storage: ShortcutStorage,
        on_show_popup: Callable[[Shortcut], None],
        on_hide_popup: Callable[[], None],
        on_expanded: Optional[Callable[[Shortcut], None]] = None,
    ) -> None:
        self._storage = storage
        self._on_show_popup = on_show_popup
        self._on_hide_popup = on_hide_popup
        self._on_expanded = on_expanded

        self._simulating = threading.Event()
        self._paster = ClipboardPaster(self._simulating)

        self._state_lock = threading.RLock()
        self._buffer: str = ""
        self._pending_match: Optional[Shortcut] = None

        # Modifier tracking
        self._ctrl_down = False
        self._alt_down = False
        self._alt_gr_down = False
        self._cmd_down = False

        self._kb_listener: Optional[keyboard.Listener] = None
        self._mouse_listener: Optional[mouse.Listener] = None

    def start(self) -> None:
        if self._kb_listener is not None:
            return

        listener_kwargs = {
            "on_press": self._on_key_press,
            "on_release": self._on_key_release,
        }
        if sys.platform == "win32":
            listener_kwargs["win32_event_filter"] = self._win32_event_filter

        self._kb_listener = keyboard.Listener(**listener_kwargs)
        self._mouse_listener = mouse.Listener(on_click=self._on_mouse_click)
        self._kb_listener.start()
        self._mouse_listener.start()

    def stop(self) -> None:
        if self._kb_listener is not None:
            self._kb_listener.stop()
            self._kb_listener = None
        if self._mouse_listener is not None:
            self._mouse_listener.stop()
            self._mouse_listener = None

    def reset_buffer(self) -> None:
        with self._state_lock:
            self._buffer = ""
            had_match = self._pending_match is not None
            self._pending_match = None
        if had_match:
            self._on_hide_popup()

    def accept_popup_from_ui(self) -> None:
        """Called when the user clicks the floating suggestion popup directly."""
        with self._state_lock:
            match = self._pending_match
            self._pending_match = None
            self._buffer = ""
        self._on_hide_popup()
        if match is not None:
            self._dispatch_expansion(match, include_delimiter=False)

    def _win32_event_filter(self, msg: int, data) -> bool:
        """
        Low-level Windows keyboard filter.
        Runs on the hook thread: must return immediately without blocking.
        Used to cleanly swallow Tab/Enter/Esc when the Mode A popup is active.
        """
        try:
            if (getattr(data, "flags", 0) & LLKHF_INJECTED) or self._simulating.is_set():
                return True

            if msg not in (WM_KEYDOWN, WM_SYSKEYDOWN):
                return True

            settings = self._storage.get_settings()
            if not settings.enabled or settings.mode != "popup":
                return True

            with self._state_lock:
                pending = self._pending_match

            if pending is None:
                return True

            vk = getattr(data, "vkCode", 0)
            if vk in (VK_TAB, VK_RETURN):
                # Schedule expansion BEFORE suppress_event() because suppress_event() raises SuppressException
                with self._state_lock:
                    match = self._pending_match
                    self._pending_match = None
                    self._buffer = ""
                self._on_hide_popup()
                if match is not None:
                    self._dispatch_expansion(match, include_delimiter=False)
                if self._kb_listener is not None:
                    self._kb_listener.suppress_event()
                return False

            if vk == VK_ESCAPE:
                self.reset_buffer()
                if self._kb_listener is not None:
                    self._kb_listener.suppress_event()
                return False
        except Exception:
            pass
        return True

    def _on_mouse_click(self, _x: int, _y: int, _button, pressed: bool) -> None:
        if pressed:
            self.reset_buffer()

    def _update_modifier(self, key, is_down: bool) -> bool:
        if key in (keyboard.Key.ctrl_l, keyboard.Key.ctrl_r, keyboard.Key.ctrl):
            self._ctrl_down = is_down
            return True
        if key in (keyboard.Key.alt_l, keyboard.Key.alt):
            self._alt_down = is_down
            return True
        if key in (keyboard.Key.alt_gr, keyboard.Key.alt_r):
            self._alt_gr_down = is_down
            return True
        if key in (keyboard.Key.cmd, keyboard.Key.cmd_l, keyboard.Key.cmd_r):
            self._cmd_down = is_down
            return True
        return False

    def _on_key_release(self, key) -> None:
        self._update_modifier(key, False)

    def _on_key_press(self, key) -> None:
        if self._simulating.is_set():
            return

        if self._update_modifier(key, True):
            return

        settings = self._storage.get_settings()
        if not settings.enabled:
            return

        # Ignore command chords like Ctrl+C, Ctrl+V, Win+R (but allow AltGr for @, €, etc.)
        if (self._ctrl_down and not self._alt_gr_down) or self._cmd_down or self._alt_down:
            self.reset_buffer()
            return

        # Handle Backspace accurately in rolling buffer
        if key == keyboard.Key.backspace:
            with self._state_lock:
                self._buffer = self._buffer[:-1]
                buf = self._buffer
            if settings.mode == "popup":
                self._evaluate_popup_match(buf, settings.global_case_sensitive)
            return

        # Handle Space / Enter delimiters
        if key in (keyboard.Key.space, keyboard.Key.enter):
            with self._state_lock:
                buf = self._buffer
                self._buffer = ""
                pending = self._pending_match
                self._pending_match = None

            if settings.mode == "popup":
                # If Enter reached here (e.g. non-Win32), or Space pressed, dismiss popup
                if pending is not None:
                    self._on_hide_popup()
                return

            # Mode B: Instant Auto-Expand on Space or Enter
            if settings.mode == "instant" and buf:
                match = self._find_match(buf, settings.global_case_sensitive)
                if match is not None:
                    self._dispatch_expansion(match, include_delimiter=True)
            return

        # Reset buffer on navigation / boundary keys
        if key in (
            keyboard.Key.tab,
            keyboard.Key.esc,
            keyboard.Key.left,
            keyboard.Key.right,
            keyboard.Key.up,
            keyboard.Key.down,
            keyboard.Key.home,
            keyboard.Key.end,
            keyboard.Key.page_up,
            keyboard.Key.page_down,
        ):
            self.reset_buffer()
            return

        # Extract printable character (supports Turkish chars: ğ, ü, ş, ı, İ, ö, ç)
        char = getattr(key, "char", None)
        if not char or ord(char) < 32:
            return

        with self._state_lock:
            self._buffer = (self._buffer + char)[-MAX_BUFFER_LENGTH:]
            buf = self._buffer

        if settings.mode == "immediate":
            match = self._find_match(buf, settings.global_case_sensitive)
            if match is not None:
                with self._state_lock:
                    self._buffer = ""
                    self._pending_match = None
                self._dispatch_expansion(match, include_delimiter=False)
        elif settings.mode == "popup":
            self._evaluate_popup_match(buf, settings.global_case_sensitive)

    def _find_match(self, buffer_text: str, global_case_sensitive: bool) -> Optional[Shortcut]:
        if not buffer_text:
            return None

        shortcuts = self._storage.get_shortcuts()
        # Sort longest trigger first so specific triggers take precedence over shorter suffixes
        shortcuts.sort(key=lambda s: len(s.trigger), reverse=True)

        for sc in shortcuts:
            trigger = sc.trigger
            if not trigger or len(buffer_text) < len(trigger):
                continue

            is_case_sensitive = global_case_sensitive or sc.case_sensitive
            candidate = buffer_text[-len(trigger):]

            if is_case_sensitive:
                matched = candidate == trigger
            else:
                # Turkish-aware case-insensitive fallback (.casefold + İ/I normalization)
                matched = self._normalize_tr(candidate) == self._normalize_tr(trigger)

            if not matched:
                continue

            # Ensure trigger starts at word boundary (start of buffer or preceded by non-alnum)
            if len(buffer_text) > len(trigger):
                prev_char = buffer_text[-len(trigger) - 1]
                if prev_char.isalnum():
                    continue

            return sc

        return None

    @staticmethod
    def _normalize_tr(text: str) -> str:
        return text.replace("İ", "i").replace("I", "ı").lower()

    def _evaluate_popup_match(self, buffer_text: str, global_case_sensitive: bool) -> None:
        match = self._find_match(buffer_text, global_case_sensitive)
        with self._state_lock:
            prev_match = self._pending_match
            self._pending_match = match

        if match is not None:
            self._on_show_popup(match)
        elif prev_match is not None:
            self._on_hide_popup()

    def _dispatch_expansion(self, shortcut: Shortcut, include_delimiter: bool) -> None:
        backspace_count = len(shortcut.trigger) + (1 if include_delimiter else 0)

        def _worker() -> None:
            self._paster.replace_trigger_with_text(
                backspace_count=backspace_count,
                expansion_text=shortcut.expansion,
            )
            if self._on_expanded is not None:
                self._on_expanded(shortcut)

        threading.Thread(target=_worker, daemon=True).start()
