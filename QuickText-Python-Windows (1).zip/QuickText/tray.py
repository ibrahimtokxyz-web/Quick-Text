from __future__ import annotations

import threading
from typing import Callable, Optional

from PIL import Image, ImageDraw
import pystray


def create_tray_icon_image(active: bool = True) -> Image.Image:
    """Generate a crisp minimalist monochrome system tray icon with Pillow."""
    size = 64
    img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # Outer dark rounded square
    bg_color = (24, 24, 24, 255)
    border_color = (255, 255, 255, 255) if active else (115, 115, 115, 255)
    draw.rounded_rectangle([4, 4, 60, 60], radius=14, fill=bg_color, outline=border_color, width=3)

    # Minimalist chevron / expansion glyph inside
    glyph_color = (255, 255, 255, 255) if active else (115, 115, 115, 255)
    # Left bracket-chevron ">"
    draw.line([(18, 22), (30, 32), (18, 42)], fill=glyph_color, width=4, joint="curve")
    # Expansion bar "_"
    draw.line([(34, 41), (46, 41)], fill=glyph_color, width=4)

    return img


class SystemTrayController:
    """Manages Windows System Tray icon and right-click menu."""

    def __init__(
        self,
        on_open_dashboard: Callable[[], None],
        on_toggle_listening: Callable[[], None],
        on_exit: Callable[[], None],
        is_listening_fn: Callable[[], bool],
    ) -> None:
        self._on_open_dashboard = on_open_dashboard
        self._on_toggle_listening = on_toggle_listening
        self._on_exit = on_exit
        self._is_listening_fn = is_listening_fn
        self._icon: Optional[pystray.Icon] = None
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        if self._icon is not None:
            return

        active = self._is_listening_fn()
        menu = pystray.Menu(
            pystray.MenuItem("Open Dashboard", self._handle_open, default=True),
            pystray.MenuItem(
                lambda _item: "Pause Listening" if self._is_listening_fn() else "Resume Listening",
                self._handle_toggle,
            ),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Exit", self._handle_exit),
        )

        self._icon = pystray.Icon(
            name="QuickText",
            icon=create_tray_icon_image(active=active),
            title="QuickText — Text Expander",
            menu=menu,
        )
        self._thread = threading.Thread(target=self._icon.run, daemon=True)
        self._thread.start()

    def refresh_state(self) -> None:
        if self._icon is None:
            return
        active = self._is_listening_fn()
        self._icon.icon = create_tray_icon_image(active=active)
        self._icon.title = f"QuickText — {'Listening' if active else 'Paused'}"
        try:
            self._icon.update_menu()
        except Exception:
            pass

    def stop(self) -> None:
        if self._icon is not None:
            try:
                self._icon.stop()
            except Exception:
                pass
            self._icon = None

    def _handle_open(self, _icon, _item) -> None:
        self._on_open_dashboard()

    def _handle_toggle(self, _icon, _item) -> None:
        self._on_toggle_listening()

    def _handle_exit(self, _icon, _item) -> None:
        self._on_exit()
